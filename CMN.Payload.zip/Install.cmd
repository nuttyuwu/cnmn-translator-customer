@echo off
setlocal
echo CMN AutoCAD Translator - offline installation
echo Close AutoCAD before continuing.
tasklist /FI "IMAGENAME eq acad.exe" /NH 2>nul | find /I "acad.exe" >nul
if not errorlevel 1 goto autocad_running
tasklist /FI "IMAGENAME eq CMNUpdater.exe" /NH 2>nul | find /I "CMNUpdater.exe" >nul
if not errorlevel 1 goto updater_running
if not exist "%~dp0CMNUpdater.exe" goto incomplete
if not exist "%~dp0release.json" goto incomplete
set "CMN_SETUP_UPDATER=%LOCALAPPDATA%\CmnCadTranslator\Updater"
if not exist "%CMN_SETUP_UPDATER%" mkdir "%CMN_SETUP_UPDATER%"
if errorlevel 1 goto failed
copy /Y "%~dp0CMNUpdater.exe" "%CMN_SETUP_UPDATER%\CMNUpdater.new.exe" >nul
if errorlevel 1 goto failed
move /Y "%CMN_SETUP_UPDATER%\CMNUpdater.new.exe" "%CMN_SETUP_UPDATER%\CMNUpdater.exe" >nul
if errorlevel 1 goto failed
"%CMN_SETUP_UPDATER%\CMNUpdater.exe" setup --channel stable --manifest "%~dp0release.json"
if errorlevel 1 goto failed
"%CMN_SETUP_UPDATER%\CMNUpdater.exe" update
if errorlevel 1 goto failed
echo.
echo Installation complete. Open AutoCAD and run MNVERSION.
echo Keep this extracted folder: it is your offline update source.
echo Read START-HERE.txt for translation and glossary setup.
pause
exit /b 0
:autocad_running
echo Save your drawing, close AutoCAD, then run Install.cmd again.
pause
exit /b 1
:updater_running
echo Another CMNUpdater is running. Let it finish, then retry.
pause
exit /b 1
:incomplete
echo Extract the complete Setup ZIP before running Install.cmd.
:failed
echo Installation did not complete. Keep this window's message for your IT contact.
pause
exit /b 1
